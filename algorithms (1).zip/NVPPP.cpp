#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
const int MAXN=100010, INF=987654;
int main (){
    int n, a[MAXN];
    cin>>n;
    for(int i=0; i<n; ++i){
            cin>>a[i];
            }
            int d[MAXN];
            d[0]=-INF;
            for(int i=1; i<=n; ++i)
            d[i]=INF;
            for(int i=0; i<n; i++)
            for(int j=1; j<=n; j++)
            if(d[j-1]<a[i] && a[i]<d[j]){
            d[j]=a[i];
            }
            for(int i=1; i<=n; i++)
            cout<<d[i]<<" ";
            system("pause");
            return 0;
            }
            
