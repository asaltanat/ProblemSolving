#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
    int n,m,k,a[11111],mk;
    cin>>n>>m>>k;
    mk=n+m;
    int cr=0;
    for(int i=1; i<=n; i++)
    {
            cin>>a[i];
            if(a[i]==1) {
                        if(m==0)
                        {
                                cr++;
                                m++;
                                }
                        m--;
                        }else
           if(a[i]==2){
                     if(k==0){
                             
                              if(m==0)
                              {
                                      cr++;
                                      m++;
                                      }  m--;
                                      }
                                      else
                                      k--;
                                     
} cout<<m<<" "<<k<<" "<<cr<<endl;
}             
    cout<<cr;
   // system("pause");
    return 0;
}
