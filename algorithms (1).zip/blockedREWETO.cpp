#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
const int maxn = 100000, s = 10000;
bool np[maxn], b[s];
int p[maxn],cnt;
int main (){
    int n, r = 0;
    cin>> n;
    int m = (int)sqrt( n + .0);
    for(int i = 2; i <= m; ++i)
    if(!np[i]){
               p[cnt++] = i;
               for(int j = i+i; j <= m; j+=i)
               np[j]=true;
               }
               
               int res = 0;
               for(int k = 0, mk = n/s; k<=mk; ++k){
                       memset(b,0,sizeof(b));
                       int x= k * s;
                       for(int i = 0; i<cnt; ++i)
                       for(int j = max((x + p[i] - 1)/p[i]-x,2); j< s; j+=p[i])
                       b[j]=true;
                       
                       if(k == 0)
                       b[0] = b[1] = true;
                       for(int i = 0; i <s && x+i<= n; ++i)
                       if(b[i]==0)
                       r++;
                       }
                       cout<<r<<" ";
                       
                       system("pause");
                       return 0;
                       }
    
