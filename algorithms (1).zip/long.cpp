#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
string s,t;
int a[10000],b[10000],n,m;
int ans[10000];
int main ()
{
    cin>>s>>t;
    n=s.length();
    m=t.length();
    for(int i=0; i<n; i++)
    {
            a[n-i]=s[i]-48;
            }
                for(int i=0; i<m; i++)
    {
            b[n-i]=t[i]-48;
            }
            for(int i=1; i<=n; i++)
            cout<<a[i];
            cout<<endl;
           int k=0, nm=(n+m)*2;
    for(int i=1; i<=m; i++)
    {
            k=0;
            for(int j=1; j<=n; j++)
            {
               k=a[j]*b[i]+ans[i+j-1];
              ans[i+j-1]=k%10;
              ans[i+j]+=k/10;
               }
               }
               for(int i=nm; i>0; i--)
               {
                       cout<<ans[i];
                       }
                       system("pause");
                       return 0;
                       }
                  
