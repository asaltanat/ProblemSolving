#include <iostream>
#include <cmath>
#include <string>
using namespace std;
 int a,b,c;
 int print(int p)
 {            
                   string s[1000],t[1000];                       
                                     t[1]="one";
                                     t[2]="two";
                                     t[3]="three";
                                     t[4]="four";
                                     t[5]="five";
                                     t[6]="six";
                                     t[7]="seven";
                                     t[8]="eight";
                                     t[9]="nine";
                                     s[2]="twenty";
                                     s[3]="thirty";
                                     s[4]="fourty";
                                     s[5]="fifty";
                                     s[11]="eleven";
                                     s[12]="twelve";
                                     s[13]="thirteen";
                                     s[14]="fourteen";
                                     s[15]="fifteen";
                                     s[16]="sixteen";
                                     s[17]="seventeen";
                                     s[18]="eighteen";
                                     s[19]="nineteen";
                                    
                                     if((p>9)&&( p<20))
                                     {
                                                 cout<<s[p];
                                                 }
                                     if(p/10>1)
                                     {
                                               cout<<s[p/10];
                                               }
     if((p%10<10)&&((p<10)||(p>=20)))
     {
                                     cout<<t[p%10];
                                     }                       
                                     }   
int main ()
{
   
    cin>>a>>b;
    c=a+b;
   print(a);
   cout<<"+";
   print(b);
   cout<<"=";
   print(c);
    system("pause");
    return 0;
}
