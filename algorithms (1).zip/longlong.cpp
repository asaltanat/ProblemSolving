#include <iostream>
#include <string>
using namespace std;
int main ()
{
    freopen("INPUT.TXT","r",stdin);
  freopen("OUTPUT.TXT","w",stdout);
    string s,t;
    long long a[10000],b[10000],ans[100000];
    long long n,cr=0,m,nm;
    getline(cin,s);
    getline(cin,t);
    n=s.length();
    m=t.length();
    for(int i=0; i<n; i++)
    a[n-i]=s[i]-48;
        for(int i=0; i<m; i++)
    b[m-i]=t[i]-48;
    nm=n+m;
    for(int i=1; i<=m; i++)
    { cr=0;
            for(int j=1; j<=n; j++)
            {
                    cr=a[j]*b[i]+ans[i+j-1];
                    ans[i+j-1]=cr%10;
                    ans[i+j]+=cr/10;
                    }
                    }
                    while (ans[nm]==0 && nm>1)
                    nm--;
                    for(int i=nm; i>=1; i--)
                    cout<<ans[i];
   // system("pause");
    return 0;
}
