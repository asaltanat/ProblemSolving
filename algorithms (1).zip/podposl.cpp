#include <iostream>
#include <cstdio>
#include <string>
using namespace std;
const int MAXN = 50010;
int p[MAXN];
string s,t,e;
void pf() {
    p[0] = 0;
    for (int i = 1; i < s.size(); i++) {
        int j = p[i - 1];
        while(s[i] != s[j] && j > 0) {
            j = p[j - 1];
        }
        if (s[i] == s[j]) {
            j++;
        }
        p[i] = j;
    }
}
int main() {
   // freopen("basis.in", "r", stdin);
   // freopen("basis.out", "w", stdout);
    cin >> s>>t;
    int y=t.length();
    e=s;
    s=t+'#'+s;
    pf();
for(int i=y+1; i<s.length(); i++)
{
      //  cout<<p[i]<<" ";
        if(p[i]==t.length())
        {
                          cout<<"yes";
                          return 0;
                          }
                            }
cout<<"no";
  // system("pause");
    return 0;
}
