#include <iostream>
#include <cmath>
#include <string>
using namespace std;
int p,a[111][111],k=0,r,n,m,mn,cr[1111];
int main()  {
 
    cin >> p;
    a[1][1]=1;
    a[2][1]=1;
    cr[1]=1;cr[2]=1;
    for (int i =3; i <= p+2; i++)  {
        cr[i]=max(cr[i-1],cr[i-2]);
            for (int j = 1; j <=cr[i]; j++)
            {
                r=a[i-1][j]+a[i-2][j]+k;
                k=r/10;
                a[i][j]=r%10;
              //  cout<<r<<" "<<k<<" "<<a[i][j]<<" ---- "<<a[i-1][j]<<" "<<a[i-2][j]<<" "<<cr[i-1]<<" "<<cr[i-2]<<"endl"<<endl;
                }
               if(k>0)  {
                        cr[i]++;
                        a[i][cr[i]]=k;
                        k=0;
                        }  
              
                }
                 for(int j=cr[p+2]; j>0; j--)
                cout<<a[p+2][j];
                cout<<endl;
                system("pause");
                return 0;
                }
                
