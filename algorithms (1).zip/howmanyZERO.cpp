#include <iostream>
#include <cmath>
#include <algorithm>
#include <fstream>
using namespace std;
const int maxn = 100010, inf = 987654;
int a[maxn], t[maxn], n, x, y, p, f, z;
void make(int v, int l, int r){
     if(l == r){
          if(a[l] ==  0)
     t[v] = 1;
     else
     t[v]= 0;
     }
     else{
          int m = (l + r) / 2;
          make(v * 2, l, m);
          make (v * 2 +1, m + 1, r);
          t[v] = t[v * 2] + t[v * 2 + 1];
          }
          }
          int which(int v, int l, int r, int p){
             // cout<<l<<" "<<r<<" "<<p<<endl;
              if(l == r){
              cout<<"ok"<<l<<" "<<r;
              return r;
              }
              else if(p > t[v])
              return -1;
              else{
              int m =(l + r) / 2;
              if(t[v * 2] >= p){
                     which(v * 2, l, m, p);
                     }
              else
              {
                  which(v * 2 + 1, m + 1, r, p - t[v * 2]);
              }
              }
              }/*
          int count(int v, int l, int r, int x, int y){
              if(l>=r)
              return 0;
              if(l == x && r == y)
              return t[v];
              else
              {
                  int m =(l + r) / 2;
                  return count(v * 2 , l, m, x, min (m, y))+ count(v * 2 + 1, m + 1, r, max(x, m + 1), y);
                  }
                  }*/
int main (){
    cin>> n;
    for(int i = 0; i < n; ++i)
    cin >> a[i];
    
   // cin>>x>>y;
    cin>>z;
    while((1 << p) < n)
    p++;
    
    for(int i = n; i <= (1<<p); ++i)
    a[i] = -1;
    n = (1 << p);
    
    make(1, 0 , n - 1);
   
   // cout<< count(1, 0, n - 1, x, y);
    cout<< which(1, 0, n - 1, z);
    system("pause");
    return 0;
}
