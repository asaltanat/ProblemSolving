#include <iostream>
#include <cmath>
#include <fstream>
#include <algorithm>
using namespace std;
#define f first
#define s second
int n,t, s, p[11111];
pair<int,int>a[11111];
void msort(int l,int r){
    if(l==r){
             return;
             }
             else if(l+1==r){
                  if(a[r].f<a[l].f){
                  t=a[r].f;a[r].f=a[l].f; a[l].f=t;
                  }
                  }
                  int m=(l+r)/2;
                  msort(l,m);
                  msort(m+1,r);
                  int cr=0,x=l,y=m+1,b[11111];
                  while(r-l+1!=cr){
                                   if(x>m){
                                            b[cr++]=a[y++].f;
                                            }
                                            else if(y>r){
                                                 b[cr++]=a[x++].f;
                                                 }
                                            else if(a[y].f>a[x].f){
                                                 b[cr++]=a[x++].f;
                                                 }
                                                 else {
                                                      if(a[y].f==a[x].f)
                                                      s++;
                                                      b[cr++]=a[y++].f;
                                                      }
                                                      }
                                                      for(int i =0; i<cr; i++){
                                                              a[l+i].f=b[i];
                                                              }
                                                              }
int main (){
    int x;
    cin>>n;
    for(int i=0; i<n; i++){
    cin>>x;
    a[i]=make_pair(x,i);
    }
    msort(0,n-1);

    if(s<2){
            cout<<"NO";
            return 0;
            }
            cout<<"YES";
            for(int j=1; j<=3; j++){
    for(int i=0; i<n; i++){
            cout<<a[i].f<<" "<<a[i].s<<endl;/*
            if(p[a[i]]==p[a[i-1]] && i>0){
                            swap(p[a[i]],p[a[i-1]]);
            }*/
            }
            cout<<endl;
            }
            system("pause");
            return 0;
            }
