#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
using namespace std;
const int MAXN=100010, INF=987654;
int main (){
    int n, a[MAXN], p[MAXN], no[MAXN];
    cin>>n;
    for(int i=0; i<n; ++i){
            cin>>a[i];
            }
  vector<int >d(n+1, INF);
            d[0]=-INF;
            no[0]=-1;
            for(int i=0; i<n; i++){
            unsigned j = (upper_bound(d.begin(), d.end(), a[i])-d.begin());
            if(d[j-1]<a[i] && a[i]<d[j]){
            d[j]=a[i];
            p[i]=no[j-1];
            no[j]=i;
            }
            }
            for(int i=1; i<=n; i++)
            cout<<d[i]<<" ";
            cout<<endl;
            vector<int>result;
            for(int i=n; i>0; i--)
            if(d[i]!=INF){
                         int  c=no[i];
                         while(c!=-1){ //for(int c=no[i]; c!=-1; c=p[c])
                          result.push_back(c);
                          c=p[c];
                          }
                          break;
                          }
                          for(int i=result.size()-1; i>=0; i--)
                          cout<<a[result[i]]<<" ";
            system("pause");
            return 0;
            }
            
