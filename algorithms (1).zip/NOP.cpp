#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
int n,m, a[1111001], b[1100111], c[1110][1101],ans[110111], r=0;   
int main (){
    freopen("a.txt","r",stdin);
    freopen("b.txt","w",stdout);
    cin>>n;
    for(int i=1; i<=n; i++)
    cin>>a[i];
    
    cin>>m;
    for(int j=1; j<=m; j++)
    cin>>b[j];
    for(int i=1; i<=n; i++){
            for(int j=1; j<=m; j++){
                    if(a[i]==b[j])
                                   c[i][j]=1+c[i-1][j-1];
                                   
                    else 
                    c[i][j]=max(c[i-1][j], c[i][j-1]);
                    }
                                   }
                                // cout<<c[n][m]<<endl;
                          int   i=n, j=m;
                    while(c[i][j]>0){
                                     if(c[i][j]==c[i-1][j]){
                                                            i--;
                                                            }
                                     else if(c[i][j]==c[i][j-1])
                                     j--;
                                     
                                     else if(c[i][j]-1==c[i-1][j-1]){
                                          r++;
                                          ans[r]=a[i];
                                          i--;
                                          j--;
                                          }
                                          }
                                          for(int t=r; t>0; t--)
                                          cout<<ans[t]<<" ";
                                          
   // system("pause");
    return 0;
}
