#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
int main (){
//freopen("input.txt","r", stdin); 
//freopen("output.txt","w", stdout);
    unsigned long long  a[111111],n,cr,m=0,i=2,k=0;
    cin>>n;
    a[1]=1;
    a[1]=1;
    cr=1;
    while(i<=n){
        for(int j=1; j<=cr; j++){
               m = a[j]*i+k;
               a[j]=m % 10;
               k=m/10;
               }
               if(k>0){
               cr++;
               a[cr]=k;k=0;
               }
               i++;    
               }
               for(int i=cr; i>0; i--)
               cout<<a[i];
               system("pause");
               return 0;
               }
