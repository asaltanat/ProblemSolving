#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <string>
using namespace std;    
   int x, y,d,b;
    int di[8]={1,1,2,2,-1,-2,-1,-2};
    int dj[8]={2,-2,1,-1,2,1,-2,-1};
    bool f=false;
void check (int u,int v,int y,int d){
          for(int i=0; i<8; i++){
           if( u+di[i]==y && v+dj[i]==d){
           f=true;}
           }
           }
int main (){
       freopen("INPUT.TXT","r",stdin); freopen("OUTPUT.TXT","w",stdout);
  
    char a,c,t;
    cin>>a>>b>>t>>c>>d;
int x=a-96, y=c-96;
    for(int i=0; i<8; i++){
           if( x+di[i]==y && b+dj[i]==d)
           {cout<<"1"<<endl;
          // /*system("pause")*/;
           return 0;
           }
           check(x+di[i],b+dj[i],y,d);
           if(f==true){
                       cout<<"2"<<endl;
            //           /*system("pause")*/;
                       return 0;
                       }
                       }
                       cout<<"NO"<<endl;
  //  /*system("pause")*/;
    return 0;
}
