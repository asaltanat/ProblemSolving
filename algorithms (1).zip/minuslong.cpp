#include <iostream>
#include <string>
#include <cmath>
#include <vector>
using namespace std;
int mm=0;
 string s,t;
 int n,m;
 vector<int>a;
 vector<int>b;
 int ans[100000];
 int compare(int n,int m)
 {  
 if(n>m)
 {
 mm=1;
       return mm;} 
  if(n<m)
  {
  mm=2;
return mm;
}
if(n==m)
  {
                    for(int i=n; i>0; i--)
                    {
                            if(b[i]>a[i])
                    {        mm=2;
                    return mm;
                    }
                            if(a[i]>b[i])
                     {       mm=1;
                            return mm;
                            }
                            }
                            }}
                     int main ()
                     {
                        
                         getline(cin,s);
                         getline(cin,t);
                         int n=s.length();
                         int m=t.length();
                         a.resize(100000);
                         b.resize(100000);
                       int   nm=max(n,m);
                       for(int i=0; i<=nm; i++)
                       {
                               a[i]=0;
                               b[i]=0;
                               }
                         for(int i=0; i<n; i++)
                         a[n-i]=s[i]-48;
                         for(int i=0; i<m; i++)
                         b[m-i]=t[i]-48; 
                         compare(n,m);
                           if(mm==2)
                         {
                                    cout<<"-";
                                  for(int i=nm; i>0; i--)
                                {  swap(a[i],b[i]);
                                  } swap(n,m);
                                  }
                                  
                                for(int i=1; i<=nm; i++)
                         {
                                if(a[i]<b[i])
                                {
                                             a[i]+=10;
                                             a[i+1]-=1;
                                             }
                                ans[i]=a[i]-b[i];
                                }
                                while(ans[nm]==0) nm--;
                                if(nm<=0)
                                {
                                         cout<<0;
                                        // system("pause");
                                         return 0;
                                         }
                                      
                            for(int i=nm; i>0; i--)
                         cout<<ans[i];   
                          
                         //     system("pause");
                         return 0;
                         }
