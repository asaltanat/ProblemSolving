#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
using namespace std;
const int MAXN=100010,INF=987654;
int a[MAXN], b[MAXN], ans[111][111];
int main (){
    int n,m;
    cin>>n;
    for(int i=1; i<=n; ++i)
    cin>>a[i];
    cin>>m;
    for(int i=1; i<=m; ++i)
    cin>>b[i];
    
    for(int i=1; i<=n; ++i){
            for(int j=1; j<=m; ++j){
                    if(a[i]==b[j]){
                                   ans[i][j]=ans[i-1][j-1]+1;
                                   }
                                   else 
                                   ans[i][j]=max(ans[i-1][j], ans[i][j-1]);
                                   }
                                   }
                                   int y=0, i=n, j=m, r[MAXN];
                    while(ans[i][j]>0){
                                                             if(ans[i][j]==ans[i-1][j])
                                                             i--;
                                                             else if(ans[i][j]==ans[i][j-1])
                                                             j--;
                                  else                           
                              if(ans[i][j]-1==ans[i-1][j-1]){
                                                        r[y]=a[i];
                                                        y++;
                                                        i--;
                                                        j--;
                                                        }
                                                             }
                                                             int p[MAXN], no[MAXN];
                                                             reverse(r, r+y);
                                                             vector<int>d(y+1,INF);
                                                             d[0]=-INF, no[0]=-1;
                                                             for(int i=0; i<y; ++i){
                                                                     unsigned j=(upper_bound(d.begin(), d.end(), r[i])-d.begin());
                                                                     if(d[j-1]<r[i] && r[i]<d[j]){
                                                                                    d[j]=r[i];
                                                                                    p[i]=no[j-1];
                                                                                    no[j]=i;
                                                                                    }
                                                                                    }
                                                                                    vector<int>sol;
                                                                                    for(int i=y; i>0; i--)
                                                                                            if(d[i]!=INF){
                                                                                                          int c=no[i];
                                                                                                          while(c!=-1){
                                                                                                                       sol.push_back(c);
                                                                                                                       c=p[c];
                                                                                                                       }
                                                                                                                       break;
                                                                                                                       
                                                                                                                       }
                                                                                                          cout<<sol.size()<<endl;
                                                                                                          for(int i=sol.size()-1; i>=0; i--)
                                                                                                          cout<<r[sol[i]]<<" ";
                                                             
                                                             
                                  // system("pause");
                                   return 0;
                                   }
