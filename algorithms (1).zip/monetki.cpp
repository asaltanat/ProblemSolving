#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
long long m,e,f,n,i,j;
long long w[10000],p[10000];
long  long t[10000];
int main ()
{
    cin>>e>>f>>n;
    for(int i=1; i<=n; i++)
    cin>>p[i]>>w[i];
    m=f-e;
    for(int j=1; j<=m; j++)
    {
            t[j]=-1;
            for(int i=1; i<=m; i++)
            if((w[i]<=j)&&(t[j-w[i]]!=-1))
            if(t[j]!=-1)
            {
                        t[j]=min(t[j],t[j-w[i]]+p[i]);
                        }
                        else
                        t[j]=t[j-w[i]]+p[i];
                        }
                        cout<<t[m]<<" ";
                        for(int j=1; j<=m; j++)
                        {
                                t[j]=-1;
                                for(int i=1; i<=n; i++)
                                if((w[i]<=j)&&(t[j-w[i]]!=-1))
                                t[j]=max(t[j],t[j-w[i]]+p[i]);
                                }
                                cout<<t[m];
                                system("pause");
                                return 0;
                                }
