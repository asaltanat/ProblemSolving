#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
using namespace std;

const int maxn=100010, inf=987654;

int a[1010][1010], d[maxn], n, A, B, C, x, b, i, j, t, s[maxn];
void print (int i, int j){
     if(a[i][j] == 0)
     return ;
      else  if(a[i - 1][j] == a[i][j])
      print (i - 1, j);
      else {
      print (i - 1, j - d[i]);
      cout<<i<<" ";
      }  
     }
int main (){
    cin >>A >> B>> C >> n;
    x = C - A;
    b = B - 1;
    for(i = 1; i<= n; ++i){
            cin >>d[i];
            }
             if(A > C){
         cout<< A <<endl<<0;
         return 0;
         }
    if(A + B < C){
         cout<< A + B << endl<<-1;
         return 0;
         }
    for(i = 1; i<= n; ++i){
            for(j = 0; j < B; j++){
                    a[i][j] = a[i - 1][j];
                    if(j >= d[i] && (a[i - 1][j - d[i]] + d[i] > a[i][j])||(a[i - 1][j - d[i]] + d[i] < a[i][j] && a[i - 1][j - d[i]] + d[i] > x))
                    {
                    a[i][j]=a[i - 1][j - d[i]] + d[i];
                    s[j]=s[j-d[i]]+1;
                    }
                    }
                    }
                    i=n;
                    j=B-1;
                    if(a[i][j]<=x){
                                   cout<<A+B<<endl<<-1;
                                   return  0;
                                   }
                    cout<<A+a[i][j]<<endl<<s[j]<<endl;
                    print (i, j);                 
                    system("pause");
                    return 0;
                    }
