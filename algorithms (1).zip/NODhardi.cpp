#include <iostream>
using namespace std;
int n, m,x=987654,y=987654;
int gcd(int a, int b, int x, int y){
    if(a==0){
             x = 0, y =1;
             cout<<x<<" "<<y<<endl;
             return b;
             }
             int x1,y1;
             int d = gcd(b%a, a, x1,y1);
             x = y1 - (b/ a) * x1;
             y = x1;
             return d;
             }
int main (){
    cin >> n>> m;
    cout<<gcd(n, m,x,y);
    
    system("pause");
    return 0;
}
