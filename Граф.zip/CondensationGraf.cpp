#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <stdio.h>
using namespace std;

long long n, m, x, y, cr;

vector< vector<long long > >a, b;
vector<long long> q, com, p;
vector<bool>u, us;

void dfs1(int v){
     u[v] = 1;
     for(int i = 0; i<a[v].size(); ++i){
             if(u[a[v][i]]==0)
             dfs1(a[v][i]);
             }
             q.push_back(v);
             }
void dfs2(int v){
     us[v] = 1;
     com.push_back(v);
     for(int i = 0; i<b[v].size(); ++i)
     if(us[b[v][i]]==0)
     dfs2(b[v][i]);
     }
             
int main (){
    cin >> n>>m;
    a.resize(n);
    b.resize(n);
    u.resize(n);
    us.resize(n);
    p.resize(n);
    for(int i = 1; i<= m; ++i){
    cin >>x>>y;
    a[x-1].push_back(y-1);
    b[y-1].push_back(x-1);
 }
 for(int i = 0; i < n; ++i)
 if(u[i]== 0)
 dfs1(i);
 
 for(int i = 0; i<n; ++i){
         int v = q[n-1-i];
        // cout<<n-1-i<<endl;
         if(us[v]==0){
                     dfs2(v);
                     cr++;
                     for(int i = 0; i< com.size(); ++i)
                     p[com[i]]=cr;
                     com.clear();
                     }
                     }
                     cout<<cr<<endl;
                     for(int i = 0; i< n; ++i)
                     cout<<p[i]<<" ";
                     system("pause");
                     return 0;
                     }
                     
