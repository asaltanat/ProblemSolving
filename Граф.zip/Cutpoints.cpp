#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <fstream>

using namespace std;

int n, tim, x, y, ch[1000100], t[1000100], f[1000100], k[10000100],cr;
vector<vector<int> >a;
vector<bool>u;
vector<int > q;
void dfs(int v, int p){
     u[v] = 1;
     t[v] = f[v] = tim++;
     for(int i = 0; i< a[v].size(); ++i){
             if(a[v][i] == p){
             continue;
             }
             if(u[a[v][i]]==1)
             f[v] = min(f[v], t[a[v][i]]);
             
             else{
                  ch[v]++;
                  dfs(a[v][i], v);
                  f[v] = min(f[v], f[a[v][i]]);
                  if(f[a[v][i]] >= t[v] && p!=-1 && k[v] ==0){
                                k[v]=1;
                  q.push_back(v);
                  }
                  }
                  }
               //   cout<<v<<" "<<ch<<endl;
                  }
int main (){
    cin >>n;
    
    a.resize(n);
    u.resize(n);
    for(int i = 0; i<n-1; ++i){
            cin >>x >> y;
            x--; y--; 
            a[x].push_back(y);
            a[y].push_back(x);
            }
            for(int i = 0; i< n; ++i)
                    if(u[i] ==0){
            dfs(i, -1);
            if(ch[i]>1)
            q.push_back(i);
            }
            cout<<q.size()<<endl;
            system("pause");
            return 0;
            }
