#include <iostream>
#include <cmath>
#include <queue>
#include <algorithm>
#include <string>
#include <vector>
using namespace std;
const int inf = 987654;
queue<int>q;
vector<int>t;
int  n, m, x, y, p[1000100], d[1000100], a[1010][1010];
bool u[1000100];

int main (){
    cin >>n;
    for(int i = 0; i < n; ++i)
    for(int j = 0; j < n; ++j)
    cin >>a[i][j];
    
    cin >>x>>y;
    x--;y--;
    q.push(x);
    for(int i = 0; i< n; ++i)
    d[i]=inf;
    d[x] = 0;
    
    p[x] = -1;
    
    while(!q.empty()){
                      int v = q.front();
                      q.pop();
                      u[v] = 1;
                      for(int i = 0; i<n; ++i)
                      if(u[i]==0 && a[v][i] == 1){
                                 q.push(i);
                                 if(d[i] >d[v]+1){
                                 p[i]=v;
                                 }
                                 d[i]=min(d[i], d[v]+1);
                                 }
                                 }
                                 if(d[y]!=inf){
                                 cout<<d[y]<<endl;
                                 int z = y;
                                 while(p[y]!=-1){
                                                 t.push_back(p[y]);
                                                 y=p[y];
                                                 }
                                                 for(int i = t.size()-1; i>=0; --i)
                                                 cout<<t[i]+1<<" ";
                                                 cout<<z+1;
                                                 }
                                                 else
                                                 cout<<"-1";
                                 system("pause");
                                 return 0;
                                 }
