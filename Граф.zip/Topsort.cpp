#include <iostream>
#include <cmath>
#include <algorithm>
#include <fstream>
using namespace std;
int n, m, x, y,a[1010][1010], k, p[1000010];
bool u[1000100];
void dfs(int v){
     if(u[v] == 0){
             u[v] = 1;
             for(int i = 1; i<=n; ++i){
                     if(a[v][i] == 1 && u[i] == 0){
                                dfs(i);
                                }
                     }
                     k++;
                     p[k] = v;
             }
             }
int main (){
    cin >> n>>m;
    bool r=0;
    for(int i =1; i<=m; ++i){
            cin >>x>>y;
            a[x][y] = 1;
            }
            for(int i = 1; i<=n; ++i){
                    if(u[i] == 0)
            dfs(i);
            }
            for(int i = 1; i<=k; ++i){
                    for(int j = i; j<=k; j++){
                            if(a[p[i]][p[j]]==1){
                                                 r = 1;
                                                 cout<<"No";
                                                 return 0;
                                                 }
                                                 }
                                                 }
                                                 if(r == 0){
                                                 cout<<"Yes\n";
                                                 for(int i = n; i>0; --i)
                                                 cout<<p[i]<<" ";
                                                 }
            system("pause");
            return 0;
            }
