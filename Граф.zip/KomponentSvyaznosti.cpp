#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
using namespace std;

int n, m, x, y, k;

vector< vector<int> >a;
vector< vector<int> >p;
vector<bool>u;
void dfs(int v){
     u[v] = true;
     p[k].push_back(v);
     for(int i = 0; i< a[v].size(); ++i)
             if(u[a[v][i]] == 0){
                           dfs(a[v][i]);
                           }
                           }
int main (){
    
    cin >> n >> m;
    a.resize(n);
    u.resize(n);
    p.resize(n);
    for(int i = 1; i<=m; ++i){
            cin >>x>> y;
            x--;
            y--;
            a[x].push_back(y);
            a[y].push_back(x);
            }
    for(int i = 0; i<n; ++i)
            if(u[i]==0){
                        dfs(i);
                        k++;/*
                        for(int j = 0; j < p.size(); ++j)
                                cout<<p[j]+1<<" ";
                                cout<<endl;
                                 */  }
                                 cout<<k<<endl;
                                 for(int i = 0; i<k; ++i){
                                         cout<<p[i].size()<<endl;
                                         for(int j = 0; j<p[i].size(); ++j)
                                         cout<<p[i][j]+1<<" ";
                                         cout<<endl;
                                         }
                            system("pause");
                            return 0;
                            }
