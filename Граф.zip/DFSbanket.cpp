#include <iostream>
#include <cmath>
#include <algorithm>
#include <fstream>
using namespace std;
int n, m, a[1010][1010], d[1000100], x, y;
bool u[10000100];
void dfs(int v){
     if(u[v]==0){
                 u[v] = 1;
                 
                 for(int i = 1; i<=n; i++){
                         if(a[v][i] == 1 && u[i] == 0){
                                    (d[v] ==1)?(d[i] = 2):(d[i] = 1);
                                    dfs(i);
                                    }
                         }
                 }
                 }
int main (){
    cin >> n>>m;
    for(int i = 1; i<=m; ++i){
            cin >>x>>y;
            a[x][y] = a[y][x] = 1;
            }
            for(int i = 1; i<=n; ++i){
            if(u[i]==0){
                    d[i] = 1;
            dfs(i);
            }
            }
            for(int i = 1; i<=n; ++i){
                    for(int j = 1; j<=n; ++j){
                            if(a[i][j] == 1 && d[i] == d[j]){
                                       cout<<"NO";
                                       return 0;
                                       }
                            }
                    }
                    cout<<"YES\n";
                    for(int i = 1; i<=n; ++i)
                    if(d[i]==1)
                    cout<<i<<" ";
            system("pause");
            return 0;
            }
