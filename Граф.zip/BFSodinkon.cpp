#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <queue>
#include <cmath>
#include <algorithm>
using namespace std;

int n, a[1010][1010], x, y, r, k;
bool f;
queue<int>q, p;
char c[1010][1010];
int main (){
    int s[8] = {1,1,-1,-1,2,2,-2,-2};
    int t[8] = {2,-2,2,-2,1,-1,1,-1};
    cin >>n;
    cin >>x>>y>>r>>k;
    x--;y--;r--;k--;
         for(int i = 0; i<n; ++i){
         for(int j = 0; j<n; ++j)
                 a[i][j] = -1;
                 }
    a[x][y]=0;
         q.push(x);
         p.push(y);
                while(!q.empty()){
                                  x=q.front();
                                  q.pop();
                                  y=p.front();
                                  p.pop();
                                  for(int i = 0; i< 8; ++i)
                                          if(x+s[i]>=0 && y+t[i] >= 0 && x+s[i]< n && y+t[i] < n && a[x+s[i]][y+t[i]]==-1){
                                                    a[x+s[i]][y+t[i]]=a[x][y]+1;
                                                    q.push(x+s[i]);
                                                    p.push(y+t[i]);
                                                    }
                                                    }
                                                    vector<int>zx, zy;
                                                    x = r;
                                                    y = k;
                 if(a[r][k]==-1)
                 cout<<"IMPOSSIBLE";
                 else
                 {
                     cout<<a[r][k]<<endl;
                     int ds=a[r][k];
                     while(ds>0){
                                      int i = 0;
                                      bool bn = 0;
                                      ds--;
                                      a[r][k] = -3;
                                      while(i< 8 && bn == 0){
                                               if(r+s[i]>=0 && k+t[i] >= 0 && r+s[i]< n && k+t[i] < n && a[r+s[i]][k+t[i]]==ds){
                                      zx.push_back(r+s[i]);
                                      zy.push_back(k+t[i]);
                                     r+=s[i];
                                     k+=t[i];
                                     bn=1;
                                     } i++;
                                     }
                                      }
                     }
                     for(int i = zx.size()-1; i>=0; --i)
                     cout<<zx[i]+1<<" "<<zy[i]+1<<endl;
                     cout<<x+1<<" "<<y+1<<endl;
                 system("pause");
                 return 0;
                 }
