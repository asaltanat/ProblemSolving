#include <iostream>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <stdio.h>
using namespace std;
int n, c, a[1010][1010];
bool u[10000], t;
void dfs(int v){
                  u[v] = 1;
                  for(int i = 1; i<=n; ++i)
                  if(a[v][i]==1 && u[i] == 0)
                  dfs(i);
                  }
int main (){
    cin >> n;
    for(int i = 1; i<=n; ++i)
    for(int j = 1; j<=n; ++j){
            cin >>a[i][j];
            c+=a[i][j];
            }
            if(c/2>=n){
                       cout<<"No";
                       return 0;
                       }
            dfs(1);
            
            for(int i = 1; i<=n; i++)
                    if(u[i]==0){
            cout<<"No";
            return 0;
            }
            cout<<"Yes";
            system ("pause");
            return 0;
            }
