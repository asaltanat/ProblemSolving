#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
using namespace std;
int n, m, a[1010][1010], s;
bool u[100100];
void dfs(int v){
             m++;
             u[v] = 1;
             for(int i = 1; i<=n; ++i)
                     if(a[v][i] == 1 && u[i] == 0){
                                u[i] = v;
                                dfs(i);
             }
     }
int main (){
    cin >>n>>s;
    
    for(int i = 1; i<= n; ++i)
    for(int j = 1; j<= n; ++j)
    cin >>a[i][j];
    
    dfs(s);
    cout<<m;
    system("pause");
    return 0;
}
