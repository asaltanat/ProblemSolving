#include <iostream>
#include <cmath>
#include <string>
using namespace std;
    string s;
    int n,a[11111],p[11111];
void pref(){
    p[0]=0;
    for(int i=1; i<n; i++){
            int j=p[i-1];
            while(s[j]!=s[i] && s[j]!=s[0]){
                             j=p[j-1];
                             
                             }
                             if(s[i]==s[j])
                             j++;
                             
                             p[i]=j;
                             }
                             }
int main (){
    getline(cin,s);
     n=s.length();
    
    pref();
    for(int i=0; i<n; i++)
    cout<<p[i];
    
    system("pause");
    return 0;
}
