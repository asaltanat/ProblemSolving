#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
using namespace std;
int main ()
{
    freopen("basis.in","r",stdin);
    freopen("basis.out","w",stdout);
    string s;
    getline (cin,s);
    int n=s.length();
    int p[11111];
    for(int i=0; i<n; i++)
    p[i]=-1;
    for(int i=1; i<n; i++)
    {
            int j=i-1;
            while(j>=0)
            {
                       if(s[i]==s[0])p[i]=0;
                       if(s[i]==s[p[j]+1])
                       {
                       p[i]=p[j]+1;
                       break;
                       }
                       j=p[j];
                       }}
                       cout<<n-(p[n-1]+1);
                      // system("pause");
                       return 0;
                       }
