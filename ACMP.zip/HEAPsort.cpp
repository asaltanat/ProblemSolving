#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
    int a[111111];
void dheap(int a[], long k,long n){
     int m=a[k];
     long ch;
     while(n/2>=k){
     ch=2*k;
     if(ch<n && a[ch]<a[ch+1]){
             ch++;
     }
     if(m>=a[ch])break;
     
     a[k]=a[ch];
     k=ch;
     }
     a[k]=m;
     }
int main (){
    int n;
    cin>>n;
    for(int i=0; i<n; i++)
    cin>>a[i];
    
    long temp;
    int r=n/2;
    if(n>3){
            r-=1;
            }
    for(int i=r; i>=0; i--)
    dheap(a,i,n-1);
    for(int i=n-1; i>0; i--){
            swap(a[n],a[0]);
            dheap(a,0,i-1);
            }
            for(int i=0; i<n; i++)
            cout<<a[i]<<" ";
                
    system("pause");
    return 0;
}
