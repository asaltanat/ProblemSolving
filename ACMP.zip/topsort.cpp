#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int n,i,j;
vector<vector <int> >a(1000);
vector<bool>u(1000);
vector<int>ans(1000);
void dfs (int v) {
	u[v]=true;
	for( i=1; i<=n; ++i) {
		int to = a[v][i];
		if (!u[to])
			dfs (to);
	}
	ans.push_back (v);
}
 
void topsort() {
	for (int i=1; i<=n; ++i)
		u[i] = false;
	ans.clear();
	for (int i=1; i<=n; ++i)
		if (!u[i])
			dfs (i);
	reverse (ans.begin(), ans.end());
}
int main ()
{
    cin>>n;
    for(int i=1; i<=n; i++)
    for(int j=1; j<=n; j++)
    cin>>a[i][j];
    topsort();
    system("pause");
    return 0;
}
