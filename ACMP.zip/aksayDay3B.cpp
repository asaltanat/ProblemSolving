#include <iostream>
#include <cmath>
using namespace std;
int n,m,cr=0;
char a[11111];
void check(){
     for(int i=0; i<=n; i++){
             cout<<a[i];
             }
             cout<<endl;
             }
             void gen(int k){
                  if(k==n && cr==m){
                           check();
                           }
                           else if(k<n){
                                if(cr<m){
                                a[k]='*';
                                cr++;
                                gen(k+1);
                                cr--;
                                }
                                a[k]='.';
                                gen(k+1);
                                
                                }
                                }
int main (){
    cin>>n>>m;
    gen(0);
    system("pause");
    return 0;
}
