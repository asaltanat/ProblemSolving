#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
const int M=222222;
int main (){
    freopen("INPUT.TXT","r",stdin);
    freopen("OUTPUT.TXT","w",stdout);
    char ch[251][251],c[251][251];
    int a[251][251],n,b[251][251];
    cin>>n;
    for(int i=1; i<=n; i++){
           b[i][0]=M;
            b[0][i]=M;
            b[n+1][i]=M;
            b[i][n+1]=M;
            for(int j=1; j<=n; j++){
            cin>>ch[i][j];
            a[i][j]=ch[i][j]-48;
            b[i][j]=a[i][j];
            }}
            //begin
            b[0][1]=0;
            for(int i=1; i<=n; i++){
                    for(int j=1; j<=n; j++){
                            c[i][j]='.';
               b[i][j]+=min(b[i-1][j],b[i][j-1]);                    
                            }
                            }
                            int i=n,j=n;
            while(i>0 && j>0){
                      c[i][j]='#';
                      if(b[i][j]-a[i][j]==b[i-1][j])
                      {
                                                    i--;
                                                    }
                                                    else{
                                                         j--;
                                                         }
                                                         }
            //end
            for(int i=1; i<=n; i++){
                    for(int j=1; j<=n; j++){
                            cout<<c[i][j];
                            }
                            cout<<endl;
                            }
                       //     /*system("pause")*/;
                            return 0;
                            }
