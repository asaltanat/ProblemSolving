#include <iostream>
#include <cstdio>

using namespace std;

bool u[110];
int q[110],h,t,n;
bool a[110][110],d[110];

int main ()
{
    cin>>n;
    for(int i=0; i<n; i++)
    for(int j=0; j<n; j++)
    cin>>a[i][j];
    
    d[0]=0;
    q[t]=0;
    t++;
    while(h<t)
    {
              int v=q[h];
              h++;
              u[v]=true;
           for(int i=0; i<n; i++)
           if(a[v][i]==true && u[i]==false)
           {cout<<i+1<<" ";
           q[t]=i;
           t++;
           u[i]=true;
           d[i]=d[v]+1;
           }
           }
           system("pause");
    return 0;
}
