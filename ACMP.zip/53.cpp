#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
    int n,m,b[4]={0,2,3,5},k[111],ans,x;
    int u[111];
    bool g[111][111];
int main (){
    freopen("INPUT.TXT","r",stdin);
    freopen("OUTPUT.TXT","w",stdout);
    cin>>n>>m;
    x=n*m;
                    for(int p = 3; p >0; --p)
                          for(int i = 1; i <= n; i++) 
                             for(int j = 1; j <= m; j++)
                                     if((i * j)%b[p]==0 && g[i][j]==0){
                                                               x--;
                                                               g[i][j]=1;
                                           k[b[p]]++;
                                           u[i*j]=b[p];
                                     }
                          cout<<"RED : "<<k[2]<<endl;
                          cout<<"GREN : "<<k[3]<<endl;
                          cout<<"BLUE : "<<k[5]<<endl;
                          cout<<"BLACK : "<<x<<endl;
                        //  system("pause");
                          return 0;
                          }
