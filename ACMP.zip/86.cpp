#include <iostream>
#include <fstream>
using namespace std;
int main (){
    freopen("INPUT.TXT","r",stdin);
    freopen("OUTPUT.TXT","w",stdout);
    int n,m;
    cin>>n;
    cout<<n*n-3*n+2;
  //  system("pause");
    return 0;
}
