#include <iostream>
#include <stack>
using namespace std;
int n,m,c,t,pr;
char a[11111];

void check(){pr++;
     for(int i=0; i<=n*2; i++)
     cout<<a[i];
     cout<<endl;
     }
     void gen (int k){
          if(k==n*2 && c==0 && t==n){
                     check();
                     }
                     else if(k<n*2){
                          if(c>0){
                          a[k]='(';
                          c--;
                          gen(k+1);
                          c++;
                          }
                          if(n-c>t){
                               a[k]=')';
                               t++;
                               gen(k+1);
                               t--;
                               }
                          }
                          }
int main (){
    cin>>n;
    c=n;
    gen(0);
//    cout<<pr;
    system("pause");
    return 0;
}
      
