#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <fstream>
using namespace std; 
  string s;
  int m,i;
int main ()
{
    //freopen("bigbadnumber.in","r",stdin);
   // freopen("bigbadnumber.out","w",stdout);
    cin>>s;
    double n=s.length();
    cin>>m;
    int i=1;
    while(i<m)
    {
              n=pow(n*1.00,3.00);
              i++;
              }
              cout<<n;
           system("pause");
              return 0;
              }
