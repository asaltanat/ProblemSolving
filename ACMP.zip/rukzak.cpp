#include <iostream>
#include <cmath>
using namespace std;

    int n,m,a[11111],b[11111],t[111][111];
int print(int x,int y){
     if(t[x][y]!=0){
    if(t[x-1][y]==t[x][y])
      print(x-1,y);
     else{
          cout<<x<<" ";
          print(x-1,y-a[x]);
          }
          }
          }
     
int main (){
    cin>>n>>m;
    for(int i=1; i<=n; i++)
    cin>>a[i]>>b[i];
    
    for(int i=0; i<=n; i++)
    t[0][i]=0;
    for(int j=0; j<=n; j++)
    t[j][0]=0;
    
    for(int i=1; i<=n; i++)
    for(int j=1; j<=m; j++){
            t[i][j]=t[i-1][j];
            if(j>=a[i] && t[i-1][j-a[i]]+b[i]>t[i][j]){
              t[i][j]=t[i-1][j-a[i]]+b[i];
              }
              }              
              print(n,m);
              system("pause");
              return 0;
              }
