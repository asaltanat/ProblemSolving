#include<iostream>
#include<string>
#include<fstream>
using namespace std;
long long n,m;
char ch;
char a[10000];
bool f;
string s;
int main()
{
    freopen("brackets.in","r",stdin);
    freopen("brackets.out","w",stdout);
    getline(cin,s);
    m=0;
    n=s.length();
    f=true;
    for (int i=0;i<n;i++)
    {
        if (s[i]=='}')
        {
                     if (a[m]=='{') m--;
                     else f=false;
        }
        else
        if(s[i]==')')
        {
                   if (a[m]=='(') m--;
                   else f=false;
        }
        else
        if (s[i]==']')
        {
                  if (a[m]=='[') m--;
                  else f=false;
                  }
        else
        {
             m++;
             a[m]=s[i];
         }
    }
    if ((m==0)&&(f)) cout<<"Yes";
    else cout<<"No";
    return 0;
}
