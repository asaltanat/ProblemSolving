#include <iostream>
#include <string>
#include <bor>
#include <vector>
using namespace std;

int n,m;
vector<int>t(11111);
string a[11111],b[11111];
struct node{
       int nx[26];
       bool isEnd;
       }t[N*100];
       void add(string s)
       {
            int v=0;
            for(int i=0; i<s.length(); i++)
            {
                    int j=s[i]-'a';
                    if(t[v].nx[j]==-1)
                    t[v].nx[j]=sz++;
                    v=t[v].nx[j];
                    }
                    t[v].isEnd=1;
                    }
                    void find(s)
                    {
                         int v=0;
                         for(int i=0; i<s.length(); i++)
                         {
                                 int j=s[v]-'a';
                                 if(t[v].nx[i]==-1)
                                 return false;
                                 v=t[v].nx[j];
                                 }
                                 return t[v].isEnd;
                                 }
                         for(int i=0; i<n; i++)
                         {
                                 
int main ()
{
    cin>>n>>m;
    for(int i=1; i<=n; i++)
    {
            cin>>a[i];
            add(a[i]);
            }
            for(int i=1; i<=m; i++)
            {
                    cin>>b[i];
                    cout<<find(b[i]);
                    }
    system("pause");
    return 0;
}
