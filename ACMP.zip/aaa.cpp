#include <iostream>
#include <string>
#include <fstream>
using namespace std;
int main ()
{
    freopen("INPUT.TXT","r",stdin);
    freopen("OUTPUT.TXT","w",stdout);
    char a,b;
    cin>>a>>b;
    int d=int(b)-int('0');
    int c=int(a)-int('A');
    c+=1;
    if((d+c)%2==0)
    cout<<"BLACK"<<endl;
    else
    cout<<"WHITE"<<endl;
    //system("pause");
    return 0;
}
