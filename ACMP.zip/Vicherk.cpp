#include <iostream>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <stdio.h>
#include <string>
using namespace std;
const int inf = 987654, maxn = 1000100;

int n, m;
string  s;
char a[maxn];
bool u[100100], t;
void gen (int k, int w){
     if(k == 3){
          int p=0;
          t = 0;
          for(int i= 1; i<=3; ++i){
                  if(a[1] - 48!=0){
                  t = 1;
                  }
          p=p*10+(a[i]-48);
          }
          if(u[p] == 0 && t == 1){
          u[p]=1;
          ++m;
          }
          }
          else if(k < 3){
               for(int i=w; i<n; ++i){
                                  a[k + 1]=s[i];
                                  gen(k + 1, i+1);
                                  }
               }
               }
int main (){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w",stdout);
    getline (cin, s);
    n = s.length();
    gen (0, 0);
    cout<<m;
   // system("pause");
    return 0;
}
