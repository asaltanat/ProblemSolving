#include <iostream>
#include <set>
#include <vector>
using namespace std;
int n,m,a[111111],b[111111],mn=789456;
int cr=0;int c[11111];
bool f=0;
void gen (int k){
     if(k==m){int v=0,p=0; 
              for(int i=1; i<=m; i++){
              v+=a[i]*b[i];
              p+=b[i];
                      }
                      if(v==n && mn>p){f=1;
                      cr=0;
                      mn=p;
                              for(int i=1; i<=m; i++){
                                      for(int j=1; j<=b[i]; j++)
                             {
                                      c[cr++]=a[i];
                                      } 
                                      }
                              }
                              }
                      else if(k<m){
                           for(int i=2; i>=0; i--){
                           b[k+1]=i;
                           gen(k+1);
                           }
                           }
                           }
     int main (){
         int x=0;
         cin>>n>>m;
         for(int i=1; i<=m; i++){
                 cin>>a[i];
                 x+=a[i]*2;
                 }
                 gen(0);
                 if(f==0 && x>n){
                         cout<<"0";
                         }
                         else if(f==0 && x<n)
                         cout<<"-1";
                          else{cout<<mn<<endl;
                               for(int i=0;i<cr; i++)
                               cout<<c[i]<<" ";
                               }
                 system("pause");
                 return 0;
                 }
