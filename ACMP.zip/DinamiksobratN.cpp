#include <iostream>
using namespace std;
int main (){
    int n, a[11111],t[110][110];
    cin>>n;
    for(int i=1; i<=n; i++)
    cin>>a[i];
    for(int i=1; i<=n;i++){
    t[0][i]=0;
    t[i][0]=1;
}t[0][0]=1;
  for(int i=1; i<=n; i++){
          for(int j=1; j<=16; j++)
                  if(j>=a[i])
                  t[i][j]=max(t[i-1][j],t[i-1][j-a[i]]);
                  else
                  t[i][j]=t[i-1][j];
                  }
                     
                  int s=16;
                  if(t[n][16]==1){
                                  for(int i=n; i>=1; i--){
                                          if(t[i][s]!=t[i-1][s]){
                                          cout<<i<<" yes ";
                                          s-=a[i];
                                          }
                                          }
                                          }/*
                                          for(int i=1; i<=n; i++){
                                                  for(int j=1; j<=16; j++)
                                                  cout<<t[i][j]<<" ";
                                                  cout<<endl;
                                                  }*/
                                          system("pause");
                                          return 0;
                                          }
    
