#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
int n, a,b,c;
int main (){
   // freopen("input.txt","r",stdin);
  //  freopen("output.txt","w",stdout);
    cin>>n;
  a=n/5;
  b=n%5;
  if(b%3==0){
             c+=b/3;
             }
             else
             while(b%3!=0){
                           b+=5;
                           a--;
                           c=b/3;
                           }
                           cout<<c<<" "<<a;
                               
    system("pause");
    return 0;
}
    
