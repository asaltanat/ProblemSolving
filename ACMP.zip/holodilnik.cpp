#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <fstream>
using namespace std;
int main ()
{
   freopen("fridge.in","r",stdin);
   freopen("fridge.out","w",stdout);
    long long a,b,c=0;
    int cr[111111];
    cin>>a>>b;
    cr[1]=10;
    cr[2]=90;
        for(int i=3; i<=b; i++)
    {
            cr[i]=cr[i-1]*10;
            }
            for(int i=a; i<=b; i++)
            {
                    c+=cr[i];
                    }
                    cout<<c;
                   // system("pause");
                    return 0;
                    }
