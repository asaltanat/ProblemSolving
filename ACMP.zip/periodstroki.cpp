#include <iostream>
#include <fstream>
#include <string>
using namespace std;
string s;
int n,p[1111111];
int main (){
    cin>>s;
    n=s.length();
    p[0]=0;
    for(int i=1; i<n; i++){
            p[i]=p[i-1];
            while(p[i]>0 && s[p[i]]!=s[i])
            p[i]=p[p[i]];
            if(s[p[i]]==s[i])
            p[i]++;    
            }
    int k=(n-p[n-1]);
    if(n%k==0)
    cout<<n/k;
    else
    cout<<1;
    system("pause");
    return 0;
}
