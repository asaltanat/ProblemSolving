#include<iostream>
#include <fstream>
#include <stdio.h>
#include <vector>
#include <algorithm>
using namespace std;

long long n,m,cr;
long long a[1111],b[1111];

void bins(int x,int l,int r)
{

    int m;
    while(l<r-1)
    {

        m=(l+r)/2;
        if(b[m]>a[x])
        {
            r=m;
        }
        else l=m;
    }
    if(b[l]==a[x])
    cr++;
    }
int main ()
{
    ///freopen("lcs.in","r",stdin);
  //  freopen("lcs.out","w",stdout);

cin>>n;
for(int i=0; i<n; i++)
cin>>a[i];
cin>>m;
for(int j=0; j<m; j++)
cin>>b[j];
sort(a,a+n);
sort(b,b+m);
for(int i=0; i<n; i++)
{
    bins(i,0,m);
}
cout<<cr;
system("pause");
    return 0;
}
