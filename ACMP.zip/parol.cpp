#include<iostream>
#include<cmath>
using namespace std;
long long n,cr=1,a[210][210],i,j,nn;
int main ()
{
    cin>>n;
for(int i=0; i<=n+1; i++)
{
 a[i][n+1]=-1;
 a[n+1][i]=-1;
 a[0][i]=-1;
 a[i][0]=-1;
}
cr=1;
i=1,j=1;
nn=n*n;
a[1][1]=cr;
  while(cr<=nn)
  {  if(a[i][j+1]==-1)
  {
      i++;
      cr++;
      a[i][j]=cr;
  }else
      {cr++;
      j++;
      a[i][j]=cr;}
      while(a[i+1][j-1]==0)
      {
          cr++;
          i++;
          j--;
          a[i][j]=cr;
      }
      if(a[i+1][j]==-1)
      {
          cr++;
          j++;
          a[i][j]=cr;
      }
else
{cr++;
      i++;
      a[i][j]=cr;
}
      while(a[i-1][j+1]==0)
      {
          cr++;
          i--;
          j++;
          a[i][j]=cr;}
  }

  for(int i=1; i<=n; i++)
  {
      for(int j=1; j<=n; j++)
      {
                   cout<<a[i][j]<<" ";
      }
      cout<<endl;
  }
system("pause");
  return 0;
}
