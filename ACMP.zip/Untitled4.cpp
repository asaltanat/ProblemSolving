#include <iostream>
#include <string>
using namespace std;
int main (){
    string s;
    getline (cin,s);
    int n,m=s.length(),d,x,y,z;
    char ch;
    cin>>n;
    for(int i=1; i<=n; i++){
            cin>>ch;
            if(ch=='-'){
                        cin>>d;
                        int p=m-d;
                        s.erase(s.begin()+d-1,s.end()-p);
                        cout<<s<<"s"<<endl;
                        }
                        else{
                             cin>>x>>y>>z;
                             int r=m-x-z+1;
                             string h(s.begin()+x-1,s.end()-r);
                             r=m-y-z+1;
                             string f(s.begin()+y-1,s.end()-r);
                             cout<<h<<" p "<<f<<endl;
                             if(h==f)cout<<"ia";
                             else cout<<"jok";
                             }
                             }
                             system("pause");
                             return 0;
                             }
