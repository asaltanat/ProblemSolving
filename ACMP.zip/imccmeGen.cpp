#include <iostream>
using namespace std;
int n,m,a[110];
void gen(int k){
     if(k==m){
              for(int i=k-1; i>=0; i--)
              cout<<a[i]<<" ";
              cout<<endl;
              }
              else if(k<m){
                   for(int i=a[k-1]+1; i<=n; i++){
                           a[k]=i;
                           gen(k+1);
                           }
                           }
                           }
int main () {
cin>>n>>m;
gen(0);
system("pause");
    return 0;
}
