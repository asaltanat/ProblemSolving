#include <iostream>
#include <cmath>
#include <string>
#include <fstream>
using namespace std;
int main (){
    char s[111111];
    int a,n, cr = 0;
    cin >> a;
    for(int i=1; i<=a; i++){
            cin>>s[i];
            }
    n=a;
    int mn=100000;
    while(n>0){int y=0;
               for(int i=1; i<=n; i++){
                       if(s[i]=='B')y++;
                       }
                       cout<<y<<" ";
                       mn=min(mn,y+cr);
                             while(s[n]!='B' && n>0){
                                              n--;
                                              }
                                              if(n>0){cr++;
                     for(int i=1; i<=n; i++){
                             s[i]=(s[i]=='B')?('A'):('B');
                             }
                                              }}
                                              cout<<min(mn,cr);
                                              system("pause");
                                              return 0;
                                              }
