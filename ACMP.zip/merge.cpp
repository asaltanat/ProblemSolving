#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
int n, a[11111];
void merge (int x,int y){
     if(y==x){
                return;
                }
                else if(y-x==1){
                     if(a[y]<a[x])
                     swap(a[x],a[y]);
                     return ;
                     }
                     int m=(x+y)/2;
                     merge(x,m);
                     merge(m+1,y);
                     int b[1111],xl=x,xr=m+1,c=0;
                     while(y-x+1!=c){
                                     if(xr>y)
                                     b[c++]=a[xl++];
                                     else if(xl>m)
                                     b[c++]=a[xr++];
                                     else
                                   if(a[xr]>a[xl])     
                                   b[c++]=a[xl++];                          
                                   else 
                                   b[c++]=a[xr++];
                                   }
                                  // cout<<c<< " = " <<x<<endl;
                                   for(int i=0; i<c; i++){        
                                   a[i+x]=b[i];
                                   //cout << b[i] <<" ";
                                   }
                                   //cout<< endl;
                                   }
                     
int main (){
    cin>>n;
    for(int i=1; i <= n; i++)
    cin >> a[i];
    
    merge(1, n);
    for(int i = 1; i <= n; i++)
    cout << a[i] <<" ";
    system("pause");
    return 0;
}
