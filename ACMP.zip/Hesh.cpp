#include<iostream>
#include <string>
#include <vector>
using namespace std;
string s, t[11111];
unsigned long long  w,h[100], h1, p, pr[100], H;
int n, m;
vector< string > u;
int main()
{
    cin>>w;
    for(int i=1; i<=w; i++)
    {
        cin>>t[i];
    }int cr=0;
    getline(cin,s);
    while(s[0]!='0'){
       getline(cin,s);
    p=1039;
    for(int v=1; v<=w; v++){
    for (int i=0; i<s.size(); i++)
        h[i]=(i?h[i-1]:0)*p+s[i];
    h1=0;
    for (int i=0; i<t[v].size(); i++)
        h1=h1*p+t[v][i];
    m=t[v].size();
    pr[0]=1; n=s.size();
    for (int i=1; i<=n; i++)
    {pr[i]=pr[i-1]*p;
     }
    for (int i=t[v].size()-1; i<s.size(); i++)
    {
        H=h[i]-((i-m<0)?0:h[i-m])*pr[m];
        if (H==h1 && u[s]==0){ cout<<s<<endl;
        u[s]=1;
        }
    }}}
    system("pause");
    return 0;
}
