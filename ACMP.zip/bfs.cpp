#include <iostream>
#include <cstdio>
using namespace std;
bool u[100];
int q[100],h,t,n;
bool a[100][100];
int d[110];
int main ()
{
    cin>>n;
    for(int i=0; i<n;i++ )
    for(int j=0; j<n; j++)
    cin>>a[i][j];
    d[0]=0;
    q[t]=0;
    t++;
    cout<<1;
    while(h<=t)
    {
              int v=q[h];
              h++;
              u[v]=true;
              for(int i=0; i< n; i++)
              if(a[v][i]==true && u[i]==false)
              {
                               q[t]=i;
                               cout<<q[t]<<" ";
                               t++;
                               u[i]=true;
                               d[i]=d[v]+1;
                              
              }
              }
              //for(int i=1; i<=n; i++)
              //cout<<
              system("pause");
 return 0;
}   
