#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
using namespace std;
int main () {
    int n;
    cin>>n;     
      int a[111][111],i=1,j=1;
    for(int i=0; i<=n*2+1+1; i++) {
            a[i][0]=-1;
            a[0][i]=-1;
            a[n*2+2][i]=-1;
            a[i][n*2+2]=-1;
            }
            int dx[4]={0,1,0,-1};
            int dy[4]={1,0,-1,0};
     
            
            int cr;
            int c=0;
            cr=(n*2+1)*(n*2+1);
            cr=(sqrt(cr+1)==n*2+1)? cr : (cr-1);
            a[1][1]=cr;
            while(cr>0)
            {
                        while(a[i+dx[c]][j+dy[c]]==0)
                        {
                                                     cr--;
                                                     a[i+dx[c]][j+dy[c]]=cr;
                                                     i+=dx[c];
                                                     j+=dy[c];
                                                     }
                                                     c++;
                                                     c%=4;
                                                     }
                                                     for(int i=1; i<=n*2+1; i++) {
                                                             for(int j=n*2+1; j>0; j--) {
                                                                     cout.width(3);
                                                                     cout<<a[j][i]<<" ";
                                                                     }
                                                                     cout<<endl;
                                                                     }
                                                                     system("pause");
                                                                     return 0;
                                                                     }
