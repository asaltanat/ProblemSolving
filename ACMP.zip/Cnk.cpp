#include <iostream>
using namespace std;
int n,a[11111];
int   katalan(int k){
      a[0]=1;
      for(int i=1; i<=n; i++){
              a[i]=0;
              for(int j=0; j<i; j++)
              a[i]+=a[j]*a[i-1-j];
              }
              return a[k
              ];
              }
int main (){
     cin>>n;
     cout<<katalan(n);
    system("pause");
    return 0;
}
