#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
int main (){
//freopen("input.txt","r", stdin); 
//freopen("output.txt","w", stdout);
    unsigned long long  a[111111],n,cr,m=0,i=2,k=0;
    cin>>n;
    a[0]=1;
    a[1]=1;
    cr=1;
    while(i<=n){
        for(int j=1; j<=cr; j++){
                
               m = a[j]*i+k;
               a[j]=m % 100;
               k=m/100;
               
               }
               if(k>0){
               cr++;
               a[cr]=k;k=0;
               }
               i++;    
               }cout<<a[cr];
               for(int i=cr-1; i>0; i--){
               if(a[i]<10)
               cout<<0;
               cout<<a[i];
               }
               system("pause");
               return 0;
               }
