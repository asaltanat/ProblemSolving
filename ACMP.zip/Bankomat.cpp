#include <iostream>
#include <fstream>
using namespace std;
int main (){
    int n,m,a[111111],f[11111];
    cin>>n>>m;
    for(int i=1; i<=n; i++)
    cin>>a[i];
    for(int i=1; i<=m; i++){
            f[i]=12345678;
            for(int j=1; j<=n; j++){
                    if(i>=a[j] && f[i-a[j]]+1<f[i])
                    f[i]=f[i-a[j]]+1;
                    }
                    }
                    if(f[m]==12345678)
                    cout<<"NON";
                    else{
                         while(m>0){
                                    for(int  i=1 ; i<=n; i++)
                                    if(f[m-a[i]]==f[m]-1){
                                    m-=a[i];
                                    cout<<a[i]<<" ";
                                    break;
                                    }
                                    }
                                    }
                         system("pause");
                         return 0;
                         }
