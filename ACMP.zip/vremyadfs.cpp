#include <iostream>
#include <cmath>
#include <stdio.h>
using namespace std;
int n,a[111][111],s[11111],t[11111];
int cr;
bool u[1111];
void dfs(int v)
{
     u[v]=true;
     cr++;
     s[v]=cr;
     for(int i=1; i<=n; i++)
     if(u[i]==false && a[v][i]==1)
     dfs(i);
     cr++;
     t[v]=cr;
     }
int main ()
{
    cin>>n;
    for(int i=1; i<=n; i++)
    for(int j=1; j<=n; j++)
    cin>>a[i][j];
    dfs(1);
    for(int i=1; i<=n; i++)
    cout<<s[i]<<" "<<t[i]<<endl;
    system("pause");
    return 0;
}
