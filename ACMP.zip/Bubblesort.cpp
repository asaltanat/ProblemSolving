#include <iostream>
#include <cmath>
using namespace std;
int main (){
    int n,a[111111];
    cin>>n;
    for(int i=1; i<=n; i++){
            cin>>a[i];
            }
    for(int i=1; i<=n; i++){
            for(int j=i; j>=1; j--){
                    if(a[j]<a[j-1])
                    swap(a[j],a[j-1]);
                    }
                    }
            for(int i=1; i<=n; i++)
            cout<<a[i]<<" ";
            
            system("pause");
            return 0;
            }
            
