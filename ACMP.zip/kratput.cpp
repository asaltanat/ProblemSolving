#include <iostream>
#include <cmath>
#include <queue>
using namespace std;
    bool u[1111]; 
       queue<int>q;
    int n,s,f,a[111][111],p[1111],d[11111],c,cd[1111];
int main () {

    cin>>n;
     for(int i=1; i<=n; i++)
    for(int j=1; j<=n; j++)
    cin>>a[i][j];
    cin>>s>>f;
    q.push(s);

    u[s]=true;
    p[s]=-1;
    while(!q.empty()) {
                      int v=q.front();
                      q.pop();//cout<<v<<endl;
                      for(int i=1; i<=n; i++)
                      {
                              if(u[i]==false && a[v][i]==1){
                              u[i]=true;
                              q.push(i);
                              d[i]=d[v]+1;
                              p[i]=v;
                              c++;
                              cd[c]=v;
                              }
                              }
                              }
                              cout<<c<<endl;
                              for(int i=1; i<=c; i++)
                              cout<<cd[i]<<" ";
                cout<<f;
                              
                              system("pause");
                              return 0;
                              }
