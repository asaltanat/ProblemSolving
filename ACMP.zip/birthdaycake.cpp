#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
using namespace std;
string s[11111];
bool  t;
unsigned long long h[11111],w,cr;
int main()
{
//    freopen("birthday.in","r",stdin);
  //  freopen("birthday.out","w",stdout);
    cin>>w;
    for(int v=1; v<=w; v++){
    cin>>s[v];
    p=1039;
    for (int i=0; i<s[v].size(); i++)
        h[v]=h[v]*p+s[v][i];
    t=true;
    
    for(int f=1; f<v; f++)
    {
            if(h[f]==h[v])
            t=false;}
if(t==true)
cr++;
}    cout<<cr<<endl;  
    
  system("pause");
    return 0;
}
