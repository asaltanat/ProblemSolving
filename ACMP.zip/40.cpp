#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
using namespace std;
int main (){
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    int n=1, m, a[22222];
    cin>>m;
    a[n]=1;
    while(m>0){
               int k=0,ans[22222];
               for(int i=1; i<=n; i++){
                       ans[i]=(a[i]*2+k)%10;
                       k=(a[i]*2+k)/10;
                       }
                       if(k!=0){
                                n++;
                                ans[n]=k;
                                }
                                for(int i=1; i<=n; i++){
                                        a[i]=ans[i];
                                        }
                                        m--;
                                        }
                                        for(int i=n; i>0; i--)
                                        cout<<a[i];
                                        
                                //        system("pause");
                                        return 0;
                                        }
    
