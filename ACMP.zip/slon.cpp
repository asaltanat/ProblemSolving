#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;
int main ()
{
    freopen("granama.in","r",stdin);
    freopen("granama.out","w",stdout);
    string a;
    getline(cin,a);
    int n=a.length();
   // for(int i=0; i<n; i++)
   // {
     //      cin>>a[i];
        //    }
            next_permutation(a.begin(),a.end());
            {
                                        for(int i=0; i<n; i++)
                                        cout<<a[i];
                                        cout<<endl;
                                        }
                                       // system("pause");
                                        return 0;
                                        }
