#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <vector>
#define f first
#define s second
using namespace std;

int n,m,cr=0;
int d[11111],mn=1000,mj,v;
bool t=false,u[11111];
pair <int,int>a[11111];
pair<int,int>b[11111];
bool cmp(pair<int,int>a,pair<int,int>b)
{
     if(a>b)
     return true;
     else
     return false;
     }
int main ()
{
  // freopen("dolbak.in","r",stdin);
  // freopen("dolbak.out","w",stdout);
cin>>n;
for(int i=1; i<=n; i++)
{
        cin>>v;
        a[i]=make_pair(v,i);
        }
        sort(a,a+n,cmp);
        cin>>m;
        for(int j=1; j<=m; j++)
        {
                cin>>v;
                b[j]=make_pair(v,j);
                }
                int i=1;
                sort(b,b+m,cmp);
                 for(int j=1; j<=m; j++)
                                {
                         while(i<=n)
                         {
                                        if(a[i].f>b[j].f)
                                        {
                                                     cr++;
                                                     d[cr]=a[i].s;
                                                     a[i].f=-1;
                                                     }
                                                     i++;
                                                     }
                                                     } 
                                                     /*if(cr!=m)
                                                     {
                                                           cout<<"-1";
                                                           return 0;
                                                           }
                                                           else*/{
                                                           for(int i=1; i<=cr; i++)
                                                           cout<<d[b[i].s]<<" ";
                                                           }
                                                              
                  system("pause");
                    return 0;
                    }
