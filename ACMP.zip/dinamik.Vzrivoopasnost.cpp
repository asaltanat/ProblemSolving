#include <iostream>
#include <cmath>
using namespace std;
int main (){
    int n,a[111111];
    cin>>n;
    a[0]=1;
    a[1]=3;
    a[2]=8;
    for(int i=3; i<=n; i++){
          a[i]=(a[i-1]+a[i-2])*2;
          }
          cout<<a[n];
          system("pause");  
          return 0;
          }
