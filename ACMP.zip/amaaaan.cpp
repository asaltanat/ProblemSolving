#include <string>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>
using namespace std;
int main ()
{
  freopen("basis.in","r",stdin);
    freopen("basis.out","w",stdout);
    string s;
    getline (cin,s);
    int n=s.length();
    int p[11111];
    for(int i=1; i<n; i++)
    {
            int j=p[i-1];
            while(j>0 && s[i]!=s[j])
            j=p[i-1];
            
                       if(s[i]==s[j])
            {         
                         p[i]=j;
                         j++;
                         }
                       }
                       cout<<n-(p[n-1]+1)+1;
                      // system("pause");
                       return 0;
                       }

    
