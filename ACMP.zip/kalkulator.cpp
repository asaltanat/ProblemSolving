#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>
using namespace std;
int main (){
    double cr=0,e,a[222222];
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
    cin>>a[i];
}
    sort(a,a+n);  
    while(n>1){
               n=(n/2)+(n%2);
    for(int i=0; i<n; i++){
            a[i]=a[i*2]+a[i*2+1];
            e=a[i]*5/100;
            
            cout<<fixed<<setprecision(2)<<e<<endl;; 
            cr+=e;
            }
            }
            cout<<fixed<<setprecision(2)<<cr; 
            system("pause");
            return 0;
            }
