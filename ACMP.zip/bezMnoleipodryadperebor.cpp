#include <iostream>
#include <cmath>
using namespace std;
int n,a[11111],m,cr;
void check(){
     for(int i=0; i<n; i++)
     cout<<a[i]<<" ";
     cout<<endl;
     }
void gen(int k,int x){
     if(k==n){
              check();
              }
              else if(k<n){
                   a[k]=1;
                   gen(k+1,0);
                   if(x+1<m){
                   a[k]=0;
                   gen(k+1,x+1);
                   }
                   }
                   }
                   
int main (){
    cin>>n>>m;
    gen(0,0);
    system("pause");
    return 0;
}
