#include <iomanip>
#include <iostream>
#include <stdio.h>
using namespace std;
int main (){
    int a,b,c;
    scanf("%d %d", &a, &b);
    c=a/b;
 printf("%d ARUZHAN %d", a, b);  
//cout << fixed <<setprecision(6) <<c;

system("pause");
 return 0;
}
