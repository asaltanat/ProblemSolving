#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>

using namespace std;

long long n,a[11111],b[11111],c[11111],cr=0,d[11111],v[11111],x[11111];
int main ()
{
    freopen("saloon.in","r",stdin);
    freopen("saloon.out","w",stdout);    
    cin>>n;
    for(int i=1; i<=n; i++)
    {
            cin>>a[i]>>b[i]>>c[i];
            d[i]=a[i]*60+b[i];
            }
        for(int i=1; i<=n; i++)
        {
                for(int j=1; j<i; j++)                
                if(d[i]<d[j]+20)
                {
                                  v[i]++;
                                  }
                if(v[i]>c[i])
                {
             cout<<a[i]<<" "<<b[i]<<endl;
             a[i]=0;
             b[i]=0;
             d[i]=d[i-1];
             x[i]=x[i-1];
                }
                 else
                {
              if(v[i]==0)
              {
                        x[i]=d[i]+20;
                                  }
                                  else
                                  {
                                      x[i]=x[i-1]+20;
                                      }
                                      cout<<x[i]/60<<" "<<x[i]%60<<endl;
                                      }
                                      }
                // system("pause");
                    return 0;
                    }  
