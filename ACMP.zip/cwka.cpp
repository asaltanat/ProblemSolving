#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>

using namespace std;

int n,a[11111],b[11111],c[11111],cr=0;
int main ()
{
    cin>>n;
    for(int i=1; i<=n; i++)
    {
            cin>>a[i]>>b[i]>>c[i];
            }
            for(int i=1; i<=n; i++)
            {
                    if(c[i]<i-1 && )
                    {
                              cout<<a[i]<<" "<<b[i]<<endl;
                              }
            else
            {
                    if(b[i]>20)
                    {
                               b[i]=(b[i]+20)%60;
                               a[i]+=(b[i]+20)/60;
                               }
                               else
                               {
                                   b[i]=(cr+20)%60;
                                   a[i]+=(cr+20)/60
                                   }
                    cout<<a[i]<<" "<<b[i]<<endl;
                    cr+=b[i];
                    }
                    }
                    system("pause");
                    return 0;
                    }          
               
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
