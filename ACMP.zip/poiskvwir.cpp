#include <iostream>
#include <vector>
#include <queue>
using namespace std;
int main (){
    int a[111][111],n,x,y;
    int d[11111];
    bool u[11111];
    vector<int>k;
    queue <int> q;
    cin>>n;
    for(int i=1; i<=n; i++)
    for(int j=1; j<=n; j++)
    cin>>a[i][j];
    cin>>x>>y;
    k.push_back(x);
    q.push(x);
    d[x]=0;
    u[5]=true;
    
    while(!(q.empty())){
                        
                        int v=q.front();
                        if(v==y){
                                 cout<<k.size()<<endl;
                                 for(int i=0; i<k.size(); i++)
                                 cout<<k[i]<<" ";
                                 
                                 system("pause");
                                 return 0;
                                 
                                 }
                        else{
                        q.pop();
    for(int i=1; i<=n; i++){
            if(a[v][i]==1 && (d[i]>d[v]+1 || d[i]==0) && i!=x){
                          q.push(i);
                          d[i]=d[v]+1;
                          u[i]=true;
                          k.push_back(i);
                          }
                          }
                          }
                          }
            system("pause");
            return 0;
            }
