//kolichestvo sravnenii O(N*N)
#include <iostream>
#include <cmath>
using namespace std;
int main (){
    int n,a[111111];
    cin>>n;
    for(int i=1; i<=n; i++)
    cin>>a[i];
    
int i, j, k;
for (int i=1; i<=n; i++)
{
k=i;
for(j=i+1; j<=n; j++)
if (a[j]<a[k]) k=j;
j=a[k]; a[k]=a[i]; a[i]=j;
}

for(int i=1; i<=n; i++)
cout<<a[i]<<" ";

system("pause");
return 0;
}
