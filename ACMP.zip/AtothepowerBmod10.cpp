#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
int binpow(int a,int b){
    if(a==0)
    return 0;
    else
    if(b==0)
    return 1;
    else if(b%2!=0)
    return (binpow(a,b-1))*a;
    else{
         int d=binpow(a,b/2);
         return d*d;
         }
         }
int main (){
    freopen("INPUTt.TXT","r",stdin);
    freopen("OUTPUTt.TXT","w",stdout);
    int a,b;
    cin>>a>>b;
    a%=10;
    b%=4;
    if (b==0){
              b=4;
              }
    cout<<(binpow(a,b))%10;
    return 0;
}
