#include <iostream>
#include <fstream>
#include <algorithm>
#include <stack>
#include <string>
#include <cmath>
using namespace std;

char a;
stack<char>s;
int i;
int main ()
{
while(cin>>a)
{
             i++;
            if(int(a)>48 && int(a)<=int('9'))
            s.push(a-48);
            else
            {
            if(a=='+')
            {
                      s[i-2]+=s[i-1];
                      }
                      if(a=='-')
                      {
                                s[i-2]-=s[i-1];
                                }
                                else
                                s[i-2]*=s[i-1];
                                }
                                cout<<s.top();
                                system("pause");
                                return 0;
                                }
                      

   system("pause");
    return 0;
}
