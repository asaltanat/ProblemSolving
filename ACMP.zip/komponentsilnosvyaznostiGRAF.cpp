#include<iostream>
using namespace std;
int j,pp,cr=0,i;
int a[111][111],v[1111],m[11111];
bool u[1111];
int n;
void dfs(int v){
     if(u[v]==false){
                     u[v]=true;
                     for(int i=1; i<=n; i++)
                     if(a[v][i]==1)
                     dfs(i);
                     m[pp]=v;
                     pp--;
                     }}
                     void dfs2(int v){
                          if(u[i]==false){
                                          u[i]=true;
                                          for(int i=1; i<=n; i++)
                                          if(a[v][i]==1)
                                          dfs2(int i);
                                          }}
int main()
{
    cin>>n;
    pp=n;
    for(int i=1; i<=n; i++)
    for(int j=1; j<=n; j++){
    cin>>a[i][j];}
    for(int i=1; i<=n; i++)
    dfs(i);
    memset(u0,size of(u))
    for(int i=1; i<=n; i++)
    if(u[v[i]]==0){
                   cr++;
                   dfs2=(v[i]);
                   }
                   system("pause");
                   return 0;
                   }
