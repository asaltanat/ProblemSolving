#include <string>
#include <iostream>
using namespace std;
    int a[111][111];
    string s,t;
int main (){
    cin>>s>>t;
    int n=s.length(),m=t.length();
    a[0][0]=0;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=m; j++){
                a[i][j]=max(a[i-1][j-1],max(a[i-1][j],a[i][j-1]));
                if(s[i-1]==t[j-1])
                a[i][j]++;
                }
                }
    for(int i=1; i<=n; i++){
            for(int j=1; j<=m; j++)
            cout<<a[i][j]<<" ";
            cout<<endl;
            }
            system("pause");
            return 0;
            }
                
