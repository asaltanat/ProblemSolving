#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <vector>
using namespace std;
int n,m,a[11111],b[11111],cr=0;
int d[11111],mn=1000,mj;
bool t=false,u[11111];
int main ()
{
   freopen("dolbak.in","r",stdin);
   freopen("dolbak.out","w",stdout);
cin>>n;
for(int i=1; i<=n; i++)
{
        cin>>a[i];
        }
        cin>>m;
        for(int i=1; i<=m; i++)
        {
                cin>>b[i];
                mn=1000;
                        for(int j=1; j<=n; j++)
                        {
                        
                                if(a[j]>b[i] &&(mn>a[j]))
                                {mn=a[j];
                                   mj=j;
                                   t=true;
                                   }
                                }
                                a[mj]=-1;
                             cr++;
                             d[cr]=mj;   
                                }
                                if(t==false || cr<m)
                                {
                                            cout<<"-1";
                                            return 0;
                                            }
                                            else
                                            {
                                                for(int i=1; i<=cr; i++)
                                                cout<<d[i]<<" ";
                                                }               
                  //system("pause");
                    return 0;
                    }
