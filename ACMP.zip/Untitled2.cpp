#include <iostream>
#include <cmath>
#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;
int main (){
    string A,B,C;
  vector<int>a;
  vector<int >b;
  vector<int>c;
  vector<int>d;
    cin>>A>>B>>C;
    int n=A.size();
    int m=B.size();
    int v=C.size();
    int z=max(n,m);
    bool f=false;
    for(int i=0; i<A.length(); i++)
    a[i]=A[n-i-1]-48;
    for(int i=0; i<B.length(); i++)
    b[i]=B[m-i-1]-48;
    for(int i=0; i<C.length(); i++)
    c[i]=C[v-i-1]-48;

    while(next_permutation(b.begin(),b.end())){
    while(next_permutation(a.begin(),a.end())){
                                               int k=0;
                                               for(int i=0; i<z; i++){
                                                d[i]=(a[i]+b[i]+k)%10;
                                                k=(a[i]+b[i])/10;   
                                                       }
                                                       if(k!=0){
                                                                d[z++]=k;
                                                       }bool t=false;
                                                       for(int i=0; i<z; i++){
                                                               if(d[i]!=c[i])t=true;
                                                               }
                                                               if(t==false){
                                                                 for(int i=n-1; i>=0; i--){
                                                              cout<<a[i];
                                                              }
                                                              cout<<" ";
                                                              for(int i=m-1; i>=0; i--){
                                                                      cout<<b[i];
                                                                      }
                                                                      system("pause");
                                                                      return 0;
                                                               }
                                                               }
                                                               }
                                                       system("pause");
                                                       return 0;
                                                       }
