#include <iostream>
#include <string>
#include <cmath>
#include <algorithm>
#include <map>
using namespace std;
    map<string, int> s;
    string t,e[11111];
    int n, a[111][111];
    bool u[11111];
void dfs(int v){
     u[v]=1;if(v!=s[t])
             cout<<e[v]<<" ";
     for(int i=1; i<=n; i++){
             if(u[i]==0 && a[v][i]==1)
             dfs(i);
             }
             }
int main (){
    cin>>n;
    string f;
    for(int i=1; i<=n; i++){
    cin>>f;
    s[f]=i;
    e[i]=f;
}   
    for(int i=1; i<=n; i++)
    for(int j=1; j<=n; j++)
    cin>>a[i][j];
    cout<<"ok";
    cin>>t;
    cout<<s[t]<<"ddddd"<<endl;
    dfs(s[t]);
system("pause");
return 0;
}    
