#include <iostream>
#include <cmath>
#include <algorithm>
#include <string>
using namespace std;
long long  n;
int vip(int n)
{
    if(n==1)
    return 0;
    else
    if(n==2){
             cout<<2;
    return 1;
}
    else{
    if(n==3)
    return 1;
    else
    if(n%3==0)
    return vip(n/3)+1;
    else
    if(n%2==0)
       return min(vip(n-1),vip(n/2))+1;
    else
    return vip(n-1)+1;
}
int main ()
{
    cin>>n;
    if(n==0)
    {
            cout<<0;
            return 0;
            }
    cout<<vip(n)<<" ";
    system("pause");
    return 0;
}
