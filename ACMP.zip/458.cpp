#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <vector>
#include <cmath>
using namespace std;
int main (){
    
    freopen ("INPUT.TXT","r",stdin);
    freopen ("OUTPUT.TXT","w",stdout);
    
    int n,  a[11111];
    char  s[11111],c;

    cin >> n;
    for (int i = 1; i <= n; i++){
            cin >> a[i];
            }
            int y = 0; 
            while(cin >> c){
                    s[y++] = c;
                    }
                    
                    int x = y/n, d[11111];
                    char ch[111][111];
                    int p=0;
                    int r;
                    bool f=0;
                    if(y%n!=0){
                          r=y%n;
                          x++;
                          f=1;
                          }
                    int w=x;
                    for(int i=1; i<=n; i++){
                                                d[i]=x;
                                               r--; 
                                       if(f==1 && r<=0){
                                               x--;
                                               f=0;
                                               }
                             for(int j=1; j<=w; j++)
                             ch[i][j]='#';
                                              }
                               for(int i=1; i<=n; i++){
                                       for(int j=1; j<=d[a[i]]; j++){
                                               if(p<=y)
                                               ch[a[i]][j]=s[p++];
                                               }
                                               }                             
                                   
                               
                                       for(int j=1; j<=w; j++){
                               for(int i=1; i<=n; i++){
                                     if(ch[i][j]!='#')
                                               cout<<ch[i][j];
                                               }
                                               }                             
                                                          
                        //  system("pause");
                                            return 0;
                                            }
