#include <iostream>
#include <stdio.h>
#include <algorithm>
using namespace std;

class treap{
      public:
        int x, y;
        struct treap *l, *r;
        
        treap(int x, int y, treap *L = NULL, treap *R = NULL){
         this ->x = x;
         this ->y = y;
         this->l = L;
         this-> r= R;
                  }
        };
        treap *merge( treap *mtreap, treap *ntreap){
              if(NULL == mtreap)
              return ntreap;
              if(NULL == ntreap)
              return mtreap;
              if(mtreap->y > ntreap->y){
                         treap* newt =  merge(mtreap->r, ntreap);
                           return new treap(mtreap->x, mtreap->y, mtreap->l, newt);
                           }
             else{
                          treap* newt = merge(mtreap, ntreap->l);
                          
                          return new treap(ntreap->x, ntreap->y, newt, ntreap->r);
                          }
              }
       treap *cut(int x, treap *duca, treap *&mtreap, treap *&ntreap){
             treap *newtreap = NULL;
             if(NULL == duca)
             ntreap = mtreap = NULL;
             if(x > duca->x){
                  
                  if(NULL == duca->r)
                  cut(x, duca->r, duca->r, ntreap);
                  
                  mtreap = duca;
                  }
             else {
                  cut(x, duca->l,mtreap, duca->l);
                  ntreap = duca;
                  }
             }
             void add(int x,int y ,treap *duca){
                   treap *nh, *mh;
                   cut(x, duca, mh, nh);
                   treap *m = new treap(x,y, NULL, NULL);
                    merge(merge(nh, m), mh);
                   }
             void show(treap *duca){
                    show(duca->l);
                    cout<<duca->x<<" ";
                    show(duca->r);
                    }
int main (){
    treap *duca = NULL;
    int n, pr,py;
    cin >>n;
    for(int i = 1; i<=n; ++i){
            cin >>pr>>py;
            add(pr,py, duca);
            }
            show(duca);
    system("pause");
    return 0;
}
