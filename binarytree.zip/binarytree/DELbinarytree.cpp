#include<iostream>
#include <cmath>
#include<stdio.h>
#include <stdlib.h>
using namespace std;

int p = 0;

struct node {
       int x;
       node *l, *r;
       };
       void show(node *&tree){
            if(tree!= NULL){
                      show(tree->l);
                      cout<<tree->x<<endl;
                      show(tree->r);
                      }
                      }
                      node *crnode(int v){
                           node *nnode = (node *)malloc(sizeof(node));
                           nnode->x = v;
                           nnode->l = NULL;
                           nnode->r = NULL;
                           return nnode;
                           }
                     node* add(int x, node *&mtree){
                           if(NULL == mtree)
                           mtree = crnode(x);
                           
                           if(x < mtree->x)
                           if(NULL == mtree->l)
                                     mtree->l = crnode(x);
                                     else
                                     add(x, mtree->l);
                           if(x > mtree->x)
                           if(NULL == mtree->r)
                           mtree->r = crnode(x);
                           else
                                          add(x, mtree->r);
                               return mtree;          
                                         } 
                     node *find(int x, node *mtree){
                          if(mtree == NULL)
                          return NULL;
                          if(x == mtree->x)
                          return mtree;
                          if(x < mtree->x)
                                return find(x, mtree->l);
                          if(x > mtree->x)
                          return find(x, mtree->r);
                          }
                          int bik(node *mtree, int cr){
                                         p = max(p, cr);
                             if(mtree->r != NULL){
                               bik(mtree->r, cr+1);
                               }
                               if(mtree->l!=NULL)
                               bik(mtree->l, cr+1);
                             return p;  
                                }         
                                
                                int right(node *mtree){
                                    while(mtree->r!=NULL)
                                    mtree = mtree->r;
                                    
                                    return mtree->x;
                                    }
                                node *del(int x, node *mtree){
                                     if(NULL == mtree)
                                     return NULL;
                                     if(mtree->x == x){
                                                 if(NULL == mtree->l && NULL == mtree->r){
                                                         free(mtree);
                                                         return NULL;
                                                         }
                                                 if(NULL == mtree->r && mtree->l!=NULL){
                                                         node *temp = mtree->l;
                                                         free(mtree);
                                                         return temp;
                                                         }
                                                 if(NULL == mtree->l && mtree->r!=NULL){
                                                         node *temp = mtree->r;
                                                         free(mtree);
                                                         return temp;
                                                         }
                                                         mtree->x = right(mtree->l);
                                                         mtree->l = del(mtree->x,mtree->l);
                                                         return mtree;
                                                 }
                                                 if(x < mtree->x){
                                                      mtree->l = del(x, mtree->l);
                                                      return mtree;
                                                      }
                                                      if(x > mtree->x){
                                                           mtree->r = del(x, mtree->r);
                                                           return mtree;
                                                           }
                                     }
                           int main (){
    node *tree = NULL;
    int x;
    while(x!=0){
                cin>>x;
                if(x==0)
                break;
                add(x, tree);
                }
                cout<<bik(tree, 0) + 1<<endl;
                int e, f, g;
                cin >>e;
                del(e,tree);
                show(tree);
   // show(tree);
    system("pause");
    return 0;
}
