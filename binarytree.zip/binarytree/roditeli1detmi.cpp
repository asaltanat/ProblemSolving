#include<iostream>
#include <cmath>
#include<stdio.h>
#include <vector>
using namespace std;
int p[1000100], pr;
struct node {
       int x;
       node *l, *r;
       };
       void show(node *&tree){
            if(tree!= NULL){
                      show(tree->l);
                      cout<<tree->x<<endl;
                      show(tree->r);
                      }
                      }
                      node *crnode(int v){
                           node *nnode = (node *)malloc(sizeof(node));
                           nnode->x = v;
                           nnode->l = NULL;
                           nnode->r = NULL;
                           return nnode;
                           }
                     node* add(int x, node *&mtree){
                           if(NULL == mtree)
                           mtree = crnode(x);
                           
                           if(x < mtree->x)
                           if(NULL == mtree->l)
                                     mtree->l = crnode(x);
                                     else
                                     add(x, mtree->l);
                           if(x > mtree->x)
                           if(NULL == mtree->r)
                           mtree->r = crnode(x);
                           else
                                          add(x, mtree->r);
                               return mtree;          
                                         } 
                     node *find(int x, node *mtree){
                          if(mtree == NULL)
                          return NULL;
                          if(x == mtree->x)
                          return mtree;
                          if(x < mtree->x)
                                return find(x, mtree->l);
                          if(x > mtree->x)
                          return find(x, mtree->r);
                          }
                          node *two(node *mtree){
                                           if(mtree->l !=NULL)
                                                       two(mtree->l);
                               if((mtree->l == NULL && mtree->r != NULL)||(mtree->r == NULL && mtree->l != NULL)){
                                           // pr++;
                                       //    p[pr] = mtree->x;
                                          cout<<mtree->x<<endl;
                                           }
                                                       if(mtree->r!=NULL)
                                                       two(mtree->r);
                               }  
                           int main (){
    node *tree = NULL;
    int x;
    while(x!=0){
                cin>>x;
                if(x==0)
                break;
                add(x, tree);
                }
                two(tree);
           //     sort(p+ 1 , p + 1 + pr);
             //   for(int i = 1; i<=pr; ++i)
               // cout<<p[i]<<endl;
   // show(tree);
    system("pause");
    return 0;
}
