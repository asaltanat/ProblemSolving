#include <iostream>
#include <cmath>
#include <string>
#include <vector>
using namespace std;
int main (){
    string s;
    getline(cin,s);
    int n=s.length(),m,a[11111];
    for(int i=0; i<n; i++){
            if(s[i]=='^')
              m=i;
              else if(s[i]=='=')
              a[i]=0;
              else 
              a[i]=s[i]-48;
              }
 int x=0,y=0;
              for(int i=0; i<m; i++)
              {
                      x+=(m-i)*a[i];
                      y+=(i+1)*a[i+m+1];
                      }
                       if(x>y) cout<<"left";
                       else if(x<y) cout<<"right";
                       else  cout<<"balance";       
             //  system("pause");
               return 0;
               }
