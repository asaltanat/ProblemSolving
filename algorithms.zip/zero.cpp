#include <iostream>
#include <string>
#include <cmath>
using namespace std;
int main ()
{
   freopen("tozero.in","r",stdin);
    freopen("tozero.out","w",stdout);
    int n,m,cr=0,x,y;
    string s;
    bool f[1111];
    int a[1111];
    cin>>n>>m;
    getline(cin,s);
    for(int i=1; i<=m; i++)
   {
    cin>>x>>y;
    if(s[x-1]==1)
    cr++;
    if(s[y-1]==1)
    cr++;
}cout<<cr;
//system("pause");
return 0;
}
