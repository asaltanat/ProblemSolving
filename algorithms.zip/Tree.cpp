#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <fstream>
using namespace std;
const int maxn = 100010, inf = 987654;
int a[maxn], b[maxn], n, x, y;
vector<int> t;
void built (int a[], int i, int l, int r){
     if(i==1)
     t.resize(n * 4 + 1);
     if(l == r)
     t[i]=a[l];
     else {
          int m = (l + r) / 2;
          built (a, i * 2, l, m);
          built (a, i * 2 + 1, m + 1, r);
          t[i]=t[i * 2]+t[i * 2 + 1];
          }
          }
     long long sum (int l, int r, int i, int tl, int tr)
      {
          if(l==tl && r==tr)
          return t[i];
          int m = (tl + tr) / 2;
          if(r <= m)
          return sum (l, r, i * 2, tl, m);
          if(l >= m)
          return sum (l, r, i * 2 + 1, m, tr);
          return sum (l, m, i * 2, tl, m) + sum (m + 1, r, i * 2 + 1, m + 1, tr);
          }
          
          int main (){
              cin>>n;
              for(int i = 0; i < n; ++i)
              cin >> a[i];
              built (a, 1, 0, n-1);
              cin>> x>> y;
              cout<<sum(x, y, 1, 0, n-1);
             // for(int i = 1; i < t.size(); ++i)
              //cout << t[i] <<" ";
              
              system ("pause");
              return 0;
              } 
