#include <string>
#include <iostream>
using namespace std;
int main (){
    string s[1111],t[1111],ch;
    int n,m,c[1111],b=0;
    cin>>n>>m;
    getline(cin,ch);
    for(int i=1; i<=n; i++){
    getline(cin,s[i]);
}
    for(int i=1; i<=n; i++)
 {   getline(cin,t[i]);
}
    while(b<n){b++;
    while(s[b]!=t[b]){
                                  char v=t[b][m-1];
            for(int i=m-1; i>0; i--){
                    t[b][i]=t[b][i-1];
                    }
                    t[b][0]=v;
                    c[b]++;
}
}
for(int i=1; i<=n; i++)
cout<<c[i]<<endl;

system("pause");
return 0;
}
