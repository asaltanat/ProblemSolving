#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
bool f[1111];
int main ()
{
    int x,n,a[111][111];
    cin>>x>>n;
    for(int i=1; i<=n; i++) {
    for(int j=1; j<=n; j++)
    cin>>a[i][j];
    f[i]=false;
}
    for(int i=1; i<=n; i++)
    {
            for(int j=1; j<=n; j++)
            {
                    if(a[j][i]==x)
                    {
                             f[i]=true;
                             }
                             }
                             }
                             for(int i=1; i<=n; i++)  
                             {
                                     if(f[i]==true)
                                     cout<<"YES";
                                     else
                                     cout<<"NO";
                                     cout<<endl;
                                     }
                                     system("pause");
                                     return 0;
                                     }
