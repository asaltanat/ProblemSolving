#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
using namespace std;
int main () {
    string s,t;
    getline(cin,s);
    for(int i=0; i<s.size(); i++) {
           if(s[i]==' ') {
                     s.erase (s.begin()+i, s.end()-(s.size()-1-i));
} s[i] = toupper(s[i]);
}
t=s;
reverse(t.begin(),t.end());
if(s==t)
cout<<"YES";
else
cout<<"NO"<<" "<<t<<" "<<s;
system("pause");
return 0;
}
