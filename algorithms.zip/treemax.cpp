#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
using namespace std;
const int maxn = 100010, inf = 987654;
int a[maxn], n, x, y, t[maxn];
bool u[maxn];
void make (int v, int l, int r){
     if(l == r){
     t[v]=a[l];
     return;
     }
     else {
     int m = (l+ r) / 2;
     make(v * 2, l, m);
     make(v * 2 + 1, m + 1, r);
     t[v] = max(t[v * 2], t[v * 2 + 1]);
     }
     }
     int find(int v, int x, int y, int l, int r){
         if(x > y)
         return 0;
         if( l == x && r == y)
         return t[v];
         else{
              int m = (l + r) / 2;
              return max(find(v* 2 , x, min(y, m), l, m), find( v * 2 + 1, max(x, m + 1),y, m + 1, r));
              }
              }
              
int main (){
    cin>>n;
    for(int i = 0; i < n; ++i)
    cin >> a[i];
    cin >> x >> y;
    int p = 0;
    while((1 << p) < n)
    p++;
    for(int i = n; i<= (1 << p); i++)
    a[i]=-inf;
        n = (1 << p);
    make(1, 0, n - 1);
    
   cout<< find(1, x, y ,0, n - 1);
    
    system("pause");
    return 0;
}
