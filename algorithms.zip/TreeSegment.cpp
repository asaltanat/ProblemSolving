#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>
using namespace std;
int a[10010], n, j, r, t[1111], x, y;

void tree(int v, int l, int r){
     if(l == r){
          t[v] = a[l];
          return ;
          }
          else {
               int m = (l + r) / 2;
               tree(v * 2, l, m);
               tree(v * 2 + 1, m + 1, r);
               t[v] = t[v * 2] + t[v * 2 + 1];
               }
               }
     void change (int v, int l, int r, int p, int d){
          if(l == r)
          t[v] = d;
          else {
               int m = (l + r) / 2;
               if(p <= m){
                    change (v * 2, l, m, p, d);
                    }
               else{
                    change (v * 2 + 1, m + 1, r, p, d);
                    }
                    t[v]=t[v * 2]+ t[v * 2 + 1];
               }
               }
              int sum (int v, int tl, int tr, int l, int r) {
	if (l > r)
		return 0;
	if (l == tl && r == tr)
		return t[v];
	int tm = (tl + tr) / 2;
	return sum (v*2, tl, tm, l, min(r,tm))
		+ sum (v*2+1, tm+1, tr, max(l,tm+1), r);
}
                 
int main (){
    int ps, d;
    cin >> n;
    for(int i = 0; i < n; ++i)
    cin >> a[i];
    cin >> x >> y;
    cin>>ps>>d;
    int p = 0;
    while((1 << p) < n)
             p++;
    n = (1 << p);
    
    tree (1, 0, n - 1);
    
    change (1, 0, n - 1, ps, d);

    cout<< sum(1, 0, n - 1, x, y);
   // for (int i = 0; i <= n; ++i)
    //cout << t[i] << " ";
    
    system("pause");
    return 0;
}
