#include <iostream>
#include <stack>
#include <string>
using namespace std;
int main () {
    stack<char>q;
    string s;
    getline(cin,s);
    for(int i=0; i<s.length(); i++){
            if(s[i]=='{' || s[i]=='[' || s[i]=='(')
            q.push(s[i]);
            else
            {
               if(q.empty()){
                              cout<<"no"; 
                                      return 0;
                              }
            else {if(s[i]=='}'){
                          if(q.top()=='{')
                          q.pop();
                          }
            if(s[i]==']'){
                          if(q.top()=='[')
                          q.pop();
                           }
                          if(s[i]==')')
                          {
                                       if(q.top()=='(')
                                       q.pop();
                                          }
                                       }}
                                       }
                                       if(q.empty())
                                       cout<<"yes";
                                       else
                                       cout<<"no";
                                     //  system("pause");
                                       return 0;
                                       }
                                       
