#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdio>
using namespace std;

typedef long long ll;
struct edge{
	int v,to;ll cap,flow;
};
ll flow;
bool u[510];
vector<int> G[510];
vector<edge> E;
int n, m;
long long k;
void addEdge(int v,int to,int cap){
	edge e1={v,to,cap,0};//edge(v,to,cap,0);
 	edge e2={to,v, 0 ,0};//edge(to,v, 0 ,0);
	G[v].push_back(int(E.size())); E.push_back(e1);
	G[to].push_back(int(E.size())); E.push_back(e2);
}

bool dfs(int v){
       	u[v]=true;
	if(v==n) return true;
	for(int i=0;i<G[v].size();i++){
		if (E[G[v][i]].cap - E[G[v][i]].flow >=k && !u[E[G[v][i]].to])
			if(dfs(E[G[v][i]].to)) {
				E[G[v][i]  ].flow += k;
				E[G[v][i]^1].flow -= k;
				return true;
			}
	}
	return false;
}

int main() {
	//freopen("input.txt", "r", stdin);	freopen("output.txt", "w", stdout);

	int v, to, cost ,mx=0;
	cin >> n >> m; E.reserve(2*m);

	for (int i = 1; i <= m; i++){
		scanf("%d%d%d",&v,&to,&cost);
		addEdge(v,to,cost);
		mx=max(mx,cost);
	}
	k=1;
	while(mx>k) k<<=1ll;

	while(k>=1){
		for (int i=1;i<=n;i++) u[i] = false;
		while (dfs(1)){
			for (int i=1;i<=n;i++) u[i] = false;
		   	flow += k;
     		}
		k/=2;
	}
     	cout << flow << "\n";

     return 0;
}
